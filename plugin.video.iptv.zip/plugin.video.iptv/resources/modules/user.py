import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmlwdHY=')

name = b.b64decode('SVBUVg==')

host = b.b64decode('aHR0cDovLzg1LjIwNC4yNDYuMjg=')

port = b.b64decode('ODA4MA==')